<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\Accommodation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class RoomController extends Controller
{
    public function index(Request $request, $accommodationId)
    {
        $accommodation = Accommodation::findOrFail($accommodationId);
        
        $query = Room::where('accommodation_id', $accommodationId)
            ->with(['availabilities', 'images', 'primaryImage']);

        // Only show active rooms to public
        if (!$request->user() || !$request->user()->isHost() || $accommodation->host_id !== $request->user()?->id) {
            $query->active();
        }

        $rooms = $query->get();

        return response()->json($rooms);
    }

    public function show($accommodationId, $id)
    {
        $room = Room::with(['accommodation', 'availabilities', 'images', 'primaryImage', 'activePromotions'])
            ->where('accommodation_id', $accommodationId)
            ->findOrFail($id);
        
        return response()->json($room);
    }

    /**
     * Afficher une chambre par son ID (route publique simplifiée)
     * Utilisée pour la page de détails /rooms/{id}
     */
    public function showPublic($id)
    {
        $room = Room::with(['accommodation', 'images', 'primaryImage'])
            ->where('is_active', true) // Seulement les chambres actives pour le public
            ->findOrFail($id);
        
        return response()->json($room);
    }

    public function store(Request $request, $accommodationId)
    {
        $accommodation = Accommodation::findOrFail($accommodationId);

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $request->validate([
            // Champs de base
            'name' => 'required|string|max:255',
            'name_en' => 'nullable|string|max:255',
            'type' => 'required|string|max:255',
            'description' => 'nullable|string',
            'description_en' => 'nullable|string',
            'capacity' => 'required|integer|min:1',
            'price_per_night' => 'required|numeric|min:0',
            'amenities' => 'nullable|array',
            'bedrooms' => 'required|integer|min:1',
            'bathrooms' => 'required|integer|min:1',
            
            // Système amélioré
            'room_category' => 'nullable|string|in:single,double,twin,triple,pmr,suite,other',
            'room_subcategory' => 'nullable|string',
            'bedding' => 'nullable|array',
            'bedding_custom' => 'nullable|string|max:255',
            'surface_area' => 'nullable|numeric|min:0',
            'bathroom_features' => 'nullable|array',
            'has_guest_toilet' => 'nullable|boolean',
            'has_additional_bathroom' => 'nullable|boolean',
            'basic_amenities' => 'nullable|array',
            'view_type' => 'nullable|string|in:city,garden,pool,sea,mountain,parking',
            'view_price_modifier' => 'nullable|integer|min:-100|max:100',
            'outdoor_features' => 'nullable|array',
            'outdoor_area' => 'nullable|numeric|min:0',
            'storage_options' => 'nullable|array',
            'has_living_room' => 'nullable|boolean',
            'living_room_features' => 'nullable|array',
            'has_kitchen' => 'nullable|boolean',
            'kitchen_type' => 'nullable|string|in:full,kitchenette,corner',
            'kitchen_equipment' => 'nullable|array',
            'has_dining_area' => 'nullable|boolean',
            'dining_capacity' => 'nullable|integer|min:0',
            'additional_bedrooms' => 'nullable|integer|min:0',
            'additional_bedrooms_config' => 'nullable|array',
            'premium_amenities' => 'nullable|array',
            'paid_options' => 'nullable|array',
            'has_private_pool' => 'nullable|boolean',
            'pool_heated' => 'nullable|boolean',
            'has_parking' => 'nullable|boolean',
            'parking_type' => 'nullable|string|in:garage,private,shared',
            'parking_price' => 'nullable|numeric|min:0',
            'is_pmr_accessible' => 'nullable|boolean',
            'pmr_features' => 'nullable|array',
            'single_occupancy_price' => 'nullable|numeric|min:0',
            'extra_bed_price' => 'nullable|numeric|min:0',
            'max_extra_beds' => 'nullable|integer|min:0',
            'custom_tags' => 'nullable|array',
        ]);

        // Créer la chambre avec tous les champs
        $data = $request->only([
            'name', 'name_en', 'type', 'description', 'description_en', 'capacity',
            'price_per_night', 'amenities', 'bedrooms', 'bathrooms',
            'room_category', 'room_subcategory', 'bedding', 'bedding_custom', 
            'surface_area', 'bathroom_features', 'has_guest_toilet', 'has_additional_bathroom',
            'basic_amenities', 'view_type', 'view_price_modifier', 'outdoor_features', 
            'outdoor_area', 'storage_options', 'has_living_room', 'living_room_features',
            'has_kitchen', 'kitchen_type', 'kitchen_equipment', 'has_dining_area', 
            'dining_capacity', 'additional_bedrooms', 'additional_bedrooms_config',
            'premium_amenities', 'paid_options', 'has_private_pool', 'pool_heated',
            'has_parking', 'parking_type', 'parking_price', 'is_pmr_accessible',
            'pmr_features', 'single_occupancy_price', 'extra_bed_price', 'max_extra_beds',
            'custom_tags'
        ]);

        $data['accommodation_id'] = $accommodationId;
        $data['is_active'] = false; // Désactivé par défaut jusqu'à ce que 3 images soient ajoutées

        $room = Room::create($data);

        return response()->json($room->load(['availabilities', 'images']), 201);
    }

    public function update(Request $request, $accommodationId, $id)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($id);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $request->validate([
            // Champs de base
            'name' => 'sometimes|string|max:255',
            'name_en' => 'nullable|string|max:255',
            'type' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'description_en' => 'nullable|string',
            'capacity' => 'sometimes|integer|min:1',
            'price_per_night' => 'sometimes|numeric|min:0',
            'amenities' => 'nullable|array',
            'bedrooms' => 'sometimes|integer|min:1',
            'bathrooms' => 'sometimes|integer|min:1',
            'is_active' => 'sometimes|boolean',
            
            // Système amélioré
            'room_category' => 'nullable|string|in:single,double,twin,triple,pmr,suite,other',
            'room_subcategory' => 'nullable|string',
            'bedding' => 'nullable|array',
            'bedding_custom' => 'nullable|string|max:255',
            'surface_area' => 'nullable|numeric|min:0',
            'bathroom_features' => 'nullable|array',
            'has_guest_toilet' => 'nullable|boolean',
            'has_additional_bathroom' => 'nullable|boolean',
            'basic_amenities' => 'nullable|array',
            'view_type' => 'nullable|string|in:city,garden,pool,sea,mountain,parking',
            'view_price_modifier' => 'nullable|integer|min:-100|max:100',
            'outdoor_features' => 'nullable|array',
            'outdoor_area' => 'nullable|numeric|min:0',
            'storage_options' => 'nullable|array',
            'has_living_room' => 'nullable|boolean',
            'living_room_features' => 'nullable|array',
            'has_kitchen' => 'nullable|boolean',
            'kitchen_type' => 'nullable|string|in:full,kitchenette,corner',
            'kitchen_equipment' => 'nullable|array',
            'has_dining_area' => 'nullable|boolean',
            'dining_capacity' => 'nullable|integer|min:0',
            'additional_bedrooms' => 'nullable|integer|min:0',
            'additional_bedrooms_config' => 'nullable|array',
            'premium_amenities' => 'nullable|array',
            'paid_options' => 'nullable|array',
            'has_private_pool' => 'nullable|boolean',
            'pool_heated' => 'nullable|boolean',
            'has_parking' => 'nullable|boolean',
            'parking_type' => 'nullable|string|in:garage,private,shared',
            'parking_price' => 'nullable|numeric|min:0',
            'is_pmr_accessible' => 'nullable|boolean',
            'pmr_features' => 'nullable|array',
            'single_occupancy_price' => 'nullable|numeric|min:0',
            'extra_bed_price' => 'nullable|numeric|min:0',
            'max_extra_beds' => 'nullable|integer|min:0',
            'custom_tags' => 'nullable|array',
        ]);

        $room->update($request->only([
            'name', 'name_en', 'type', 'description', 'description_en', 'capacity',
            'price_per_night', 'amenities', 'bedrooms', 'bathrooms', 'is_active',
            'room_category', 'room_subcategory', 'bedding', 'bedding_custom', 
            'surface_area', 'bathroom_features', 'has_guest_toilet', 'has_additional_bathroom',
            'basic_amenities', 'view_type', 'view_price_modifier', 'outdoor_features', 
            'outdoor_area', 'storage_options', 'has_living_room', 'living_room_features',
            'has_kitchen', 'kitchen_type', 'kitchen_equipment', 'has_dining_area', 
            'dining_capacity', 'additional_bedrooms', 'additional_bedrooms_config',
            'premium_amenities', 'paid_options', 'has_private_pool', 'pool_heated',
            'has_parking', 'parking_type', 'parking_price', 'is_pmr_accessible',
            'pmr_features', 'single_occupancy_price', 'extra_bed_price', 'max_extra_beds',
            'custom_tags'
        ]));

        return response()->json($room->load(['availabilities', 'images']));
    }

    public function destroy(Request $request, $accommodationId, $id)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($id);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        // Check if room has active bookings
        $hasBookings = $room->bookings()
            ->whereIn('status', ['pending', 'confirmed'])
            ->exists();

        if ($hasBookings) {
            return response()->json([
                'message' => 'Cannot delete room with active bookings'
            ], 400);
        }

        $room->delete();

        return response()->json(['message' => 'Room deleted successfully']);
    }

    /**
     * Upload une image pour une chambre
     */
    public function uploadImage(Request $request, $accommodationId, $roomId)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($roomId);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $request->validate([
            'image' => 'required|image|mimes:jpeg,jpg,png,webp|max:5120', // 5MB max
            'caption' => 'nullable|string|max:255',
            'caption_en' => 'nullable|string|max:255',
            'is_primary' => 'sometimes|boolean',
        ]);

        // Vérifications de sécurité
        $file = $request->file('image');
        $allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        
        if (!in_array($file->getMimeType(), $allowedMimes)) {
            return response()->json([
                'message' => 'Invalid file type. Only JPEG, PNG and WebP are allowed.'
            ], 422);
        }

        // Upload de l'image (même méthode que AccommodationController)
        $path = $file->store("rooms/{$roomId}", 'public');
        
        if (!$path) {
            return response()->json([
                'message' => 'Failed to store image file.'
            ], 500);
        }
        
        // Obtenir l'URL relative
        $url = Storage::url($path);
        
        // Fallback mutualisé : copier aussi dans public/storage si le symlink n'est pas possible
        try {
            $publicPath = public_path('storage/' . $path);
            File::ensureDirectoryExists(dirname($publicPath));
            File::copy(Storage::disk('public')->path($path), $publicPath);
        } catch (\Exception $copyException) {
            \Log::warning("Failed to copy image to public/storage (mutualized fallback)", [
                'error' => $copyException->getMessage(),
                'path' => $path,
            ]);
        }
        
        // S'assurer que l'URL est complète (avec le domaine)
        // Utiliser asset() comme pour les accommodations
        $fullUrl = asset($url);

        // Si c'est l'image principale, désactiver les autres images principales
        // Convertir les valeurs string ('true', 'false', '1', '0') en boolean
        $isPrimaryValue = $request->input('is_primary', false);
        $isPrimary = filter_var($isPrimaryValue, FILTER_VALIDATE_BOOLEAN);
        
        if ($isPrimary) {
            $room->images()->update(['is_primary' => false]);
        }

        // Obtenir le prochain ordre de tri
        $sortOrder = $room->images()->max('sort_order') + 1;

        // Créer l'enregistrement de l'image avec l'URL complète
        $image = $room->images()->create([
            'image_path' => $fullUrl,  // URL complète stockée
            'is_primary' => $isPrimary,
            'sort_order' => $sortOrder,
            'caption' => $request->caption,
            'caption_en' => $request->caption_en,
        ]);

        // Activer la chambre si elle a maintenant au moins 3 images
        $imageCount = $room->images()->count();
        if ($imageCount >= 3 && !$room->is_active) {
            $room->update(['is_active' => true]);
        }

        return response()->json([
            'image' => $image,
            'room' => $room->load(['images', 'primaryImage']),
            'images_count' => $imageCount,
            'can_activate' => $imageCount >= 3,
        ], 201);
    }

    /**
     * Supprimer une image de chambre
     */
    public function deleteImage(Request $request, $accommodationId, $roomId, $imageId)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($roomId);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $image = $room->images()->findOrFail($imageId);

        // Si c'est l'image principale et qu'il y a d'autres images, 
        // définir automatiquement la première image restante comme principale
        if ($image->is_primary) {
            $nextImage = $room->images()
                ->where('id', '!=', $imageId)
                ->orderBy('sort_order')
                ->first();
            
            if ($nextImage) {
                $nextImage->update(['is_primary' => true]);
            }
        }

        // Supprimer le fichier physique
        // Si l'URL est complète, extraire le chemin relatif
        if ($image->image_path) {
            $pathToDelete = $image->image_path;
            
            // Si c'est une URL complète, extraire le chemin après /storage/
            if (\str_starts_with($image->image_path, 'http')) {
                if (preg_match('#/storage/(.+)$#', $image->image_path, $matches)) {
                    $pathToDelete = $matches[1];
                }
            }
            
            // Supprimer de storage/app/public
            if ($pathToDelete && !str_starts_with($pathToDelete, 'http')) {
                try {
                    Storage::disk('public')->delete($pathToDelete);
                } catch (\Exception $e) {
                    \Log::warning("Failed to delete image from storage", [
                        'path' => $pathToDelete,
                        'error' => $e->getMessage()
                    ]);
                }
                
                // Supprimer aussi de public/storage (hébergement mutualisé)
                try {
                    $publicPath = public_path('storage/' . $pathToDelete);
                    if (File::exists($publicPath)) {
                        File::delete($publicPath);
                    }
                } catch (\Exception $e) {
                    \Log::warning("Failed to delete image from public/storage", [
                        'path' => $publicPath,
                        'error' => $e->getMessage()
                    ]);
                }
            }
        }

        // Même traitement pour la miniature si elle existe
        if ($image->thumbnail_path) {
            $pathToDelete = $image->thumbnail_path;
            
            if (\str_starts_with($image->thumbnail_path, 'http')) {
                if (preg_match('#/storage/(.+)$#', $image->thumbnail_path, $matches)) {
                    $pathToDelete = $matches[1];
                }
            }
            
            if ($pathToDelete && !str_starts_with($pathToDelete, 'http')) {
                try {
                    Storage::disk('public')->delete($pathToDelete);
                    
                    $publicPath = public_path('storage/' . $pathToDelete);
                    if (File::exists($publicPath)) {
                        File::delete($publicPath);
                    }
                } catch (\Exception $e) {
                    // Log mais ne pas bloquer la suppression
                }
            }
        }

        $image->delete();

        // Vérifier si la chambre a encore au moins 3 images pour rester active
        $remainingCount = $room->images()->count();
        if ($remainingCount < 3 && $room->is_active) {
            $room->update(['is_active' => false]);
            return response()->json([
                'message' => 'Image deleted successfully. Room deactivated (less than 3 images).',
                'room_deactivated' => true,
                'remaining_images' => $remainingCount
            ]);
        }

        return response()->json([
            'message' => 'Image deleted successfully',
            'remaining_images' => $remainingCount
        ]);
    }

    /**
     * Définir une image comme image principale
     */
    public function setPrimaryImage(Request $request, $accommodationId, $roomId, $imageId)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($roomId);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $image = $room->images()->findOrFail($imageId);

        // Désactiver toutes les autres images principales
        $room->images()->update(['is_primary' => false]);

        // Activer celle-ci
        $image->update(['is_primary' => true]);

        return response()->json($image);
    }

    /**
     * Réorganiser l'ordre des images
     */
    public function reorderImages(Request $request, $accommodationId, $roomId)
    {
        $room = Room::where('accommodation_id', $accommodationId)->findOrFail($roomId);
        $accommodation = $room->accommodation;

        if ($accommodation->host_id !== $request->user()->id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $request->validate([
            'image_ids' => 'required|array',
            'image_ids.*' => 'required|integer|exists:room_images,id',
        ]);

        // Mettre à jour l'ordre
        DB::transaction(function () use ($room, $request) {
            foreach ($request->image_ids as $index => $imageId) {
                $room->images()->where('id', $imageId)->update(['sort_order' => $index]);
            }
        });

        return response()->json($room->load('images'));
    }
}
